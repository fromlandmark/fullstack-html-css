# Tabelas

1 - Recria o exemplo do calendário em example.png
2 - Não te preocupes com a estilização, se usares as tags corretamente o exemplo ficará identico ao apresentado.

Não te esqueças de rever a apresentação se achares conveniente. Relembra os atributos de rowspan e colspan se achares necessário.
