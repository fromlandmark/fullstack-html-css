O objectivo é resumir toda a matéria em contexto de html e css.

A utilização do SASS fica ao teu critério, relembro só as vantagens do encapsulamento e da divisão das responsabilidades e na rapidez de propotipagem.

Perde tempo em avaliar padrões, blocos invisíveis e definição de prioridades.
Um bom projecto é definido pelo balanço entre planeamento e execução

A fonte para ambos projectos é a Inter, está disponível no google fonts.

A pasta de assets tem todos os assets que precisas para realizar este mini projeto.

## Exercício 1

Design:
https://www.figma.com/file/fPjTeQXS41ftx77hGcFvUj/Website-Final?type=design&node-id=0%3A1&mode=design&t=cCDCFAX3JnithCoY-1

Requisitos:
Representação da landing page em mobile e desktop.

## Exercício 2

Design: https://www.figma.com/file/sUXfDsMymzKpTzBffNGgEk/Edit---Loja?type=design&node-id=0%3A1&mode=design&t=uy43VxVl4qW49vt1-1

Requisitos:

- Homepage
- Página de Produto
- Página de Categoria

Em todos os exemplos de design existe vista em desktop.
Na página de produto falta o mobile, cabe-te a ti definires qual seria o mobile deste página e representares o que achas correto.

Não precisas de te focar no conceito do menu e na forma como ele abre, o foco deste projeto é a contextualização do design e na representação o mais exacta possível do design que é fornecido.
