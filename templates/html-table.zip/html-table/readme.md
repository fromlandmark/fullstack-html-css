# Tabelas

1 - Cria o teu ficheiro de html, index.html
2 - Representa a tabela no exemple.png
3 - Se quiseres, podes estilizar a tabela com css.

Não te esqueças de rever a apresentação se achares conveniente. Relembra os atributos de rowspan e colspan.
